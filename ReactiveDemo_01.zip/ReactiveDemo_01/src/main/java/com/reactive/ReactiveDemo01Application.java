package com.reactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactiveDemo01Application {

	public static void main(String[] args) {
		SpringApplication.run(ReactiveDemo01Application.class, args);
	}

}
