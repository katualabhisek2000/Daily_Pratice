package com.reactive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveDemo01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
